# Backend

NestJS + TypeORM ile geliştirilmiş sunucu tarafı uygulaması.