# NextGen Ticket Platform

Bu proje, ITIL4 uyumlu, modüler ve genişlemeye açık bir ticket yönetim platformudur.