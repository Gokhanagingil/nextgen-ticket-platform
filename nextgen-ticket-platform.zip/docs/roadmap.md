# Yol Haritası

- [ ] Frontend başlangıç
- [ ] Backend API
- [ ] Süreç entegrasyonları